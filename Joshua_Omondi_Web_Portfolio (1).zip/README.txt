JOSHUA OMONDI — PROFESSIONAL PORTFOLIO PACKAGE

WHAT TO SEND
1. Joshua_Omondi_Professional_Portfolio.pdf — easiest option for a recruiter/client to open directly from email.
2. Joshua_Omondi_Web_Portfolio.zip — interactive website version. Extract the ZIP and open index.html in Chrome/Edge.

The web portfolio is self-contained and includes the supplied professional passport photo, so the page works offline after extraction.

CONTACT
Phone: +254 112 363 673
Email: owakajoshua200@gmail.com
LinkedIn: linkedin.com/in/joshua-omondi-2656b23a7
